/*This alert will tell people that my javascript file is connected properly when they go on the website*/
alert("My JavaScript file is connected properly!");
/*This allows a user to see that the console.log is properly displayed in the console.*/
console.log("I can display text in the Console!");
